
--Products Table

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price INT NOT NULL CHECK (price > 0),
    category VARCHAR(50) NOT NULL,
    subcategory VARCHAR(50) NOT NULL
);
--Customers Table

CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL CHECK (phone ~ '^\d{4}-\d{7}$'),
    cnic VARCHAR(13) NOT NULL CHECK (cnic ~ '^\d{13}$'),
    email VARCHAR(100) NOT NULL CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);
--Cart Items Table

CREATE TABLE cart_items (
    id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(id) ON DELETE CASCADE,
    product_id INT REFERENCES products(id),
    quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0)
);
--Orders Table

CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(20) UNIQUE NOT NULL,
    customer_id INT REFERENCES customers(id),
    address VARCHAR(255) NOT NULL,
    total_amount INT NOT NULL CHECK (total_amount > 0),
    order_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL CHECK (status IN ('Pending', 'Completed'))
);
--Order Items Table

CREATE TABLE order_items (
    id SERIAL PRIMARY KEY,
    order_id INT REFERENCES orders(id) ON DELETE CASCADE,
    product_id INT REFERENCES products(id),
    quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    price INT NOT NULL CHECK (price > 0)
);
-- Insert Sample Data 

INSERT INTO products (name, price, category, subcategory) VALUES
('Embroidered Lawn Shirt', 2990, 'New In', 'stitched'),
('Classic Blue Kurta', 3990, 'Men', 'stitched'),
('Floral Printed Dupatta', 1890, 'Women', 'unstitched'),
('Sleepwear Pajama Set', 2590, 'New In', 'sleep wear'),
('Modest Abaya', 4990, 'Women', 'modest'),
('Mini Kurta - Son Edition', 2290, 'Mini Me', 'like daddy like son'),
('Chic Western Top', 2790, 'Women', 'west'),
('Noir - Eau de Parfum', 3490, 'Fragrances', 'for him');

INSERT INTO customers (username, password, phone, cnic, email) VALUES
('ali', 'pass123', '0301-2345678', '3520212345671', 'ali@gmail.com'),
('sara_k', 'sara2024', '0300-1122334', '3310011223344', 'sara@gmail.com'),
('hassan07', 'hello@123', '0312-9988776', '3740576432109', 'hassan@yahoo.com'),
('fatima92', 'passfatima', '0321-5544332', '4210167890123', 'fatima@hotmail.com'),
('ali_beta', 'betapass', '0333-4433221', '3610212345678', 'ali@example.com'),
('ayesha_a', 'ayesha2025', '0345-6677889', '3230112233445', 'ayesha@gmail.com');

INSERT INTO cart_items (customer_id, product_id, quantity) VALUES
(1, 1, 1), -- ali buys Embroidered Lawn Shirt
(1, 2, 1), -- ali buys Classic Blue Kurta
(2, 3, 1), -- sara_k buys Floral Printed Dupatta
(3, 4, 2), -- hassan07 buys 2 Sleepwear Pajamas
(4, 7, 1); -- fatima92 buys Chic Western Top

INSERT INTO orders (order_id, customer_id, address, total_amount, order_date, status) VALUES
('20250609101001', 1, '123 Street Lahore', 6980, '2025-06-09 10:10:01', 'Pending'),
('20250609101500', 2, 'House 9, Islamabad', 1890, '2025-06-09 10:15:00', 'Completed'),
('20250609102500', 4, 'Flat 3A, Peshawar', 2790, '2025-06-09 10:25:00', 'Pending'),
('20250609103015', 3, 'House 88, Quetta', 3490, '2025-06-09 10:30:15', 'Pending'),
('20250609104010', 6, 'Sapphire HQ Lahore', 3990, '2025-06-09 10:40:10', 'Pending');

-- Ali's Order (order_id 1)
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 2, 1, 3990),
(1, 1, 1, 2990);

-- Sara's Order
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(2, 3, 1, 1890);

-- Fatima's Order
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(3, 7, 1, 2790);

-- Hassan's Order
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(4, 8, 1, 3490);

-- Ayesha's Order
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(5, 2, 1, 3990);
select * from customers;
select* from products;
select* from cart_items;
select * from orders;
select *from order_items;
SELECT o.order_id, c.username, o.total_amount, o.status, o.order_date
FROM orders o
JOIN customers c ON o.customer_id = c.id;
SELECT c.username, p.name, ci.quantity, (p.price * ci.quantity) AS total_price
FROM cart_items ci
JOIN customers c ON ci.customer_id = c.id
JOIN products p ON ci.product_id = p.id;
SELECT o.order_id, p.name AS product_name, oi.quantity, oi.price
FROM order_items oi
JOIN orders o ON oi.order_id = o.id
JOIN products p ON oi.product_id = p.id;
SELECT c.username, SUM(p.price * ci.quantity) AS cart_total
FROM cart_items ci
JOIN customers c ON ci.customer_id = c.id
JOIN products p ON ci.product_id = p.id
GROUP BY c.username;
SELECT c.username, SUM(o.total_amount) AS total_spent
FROM orders o
JOIN customers c ON o.customer_id = c.id
GROUP BY c.username
ORDER BY total_spent DESC;
SELECT category, COUNT(*) AS total_products
FROM products
GROUP BY category;
SELECT * FROM products WHERE subcategory ILIKE'stitched';
SELECT * FROM orders WHERE status = 'Pending';











